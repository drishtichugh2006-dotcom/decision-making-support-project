package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText email, password;
    Button loginBtn;
    CheckBox anonymousCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        anonymousCheck = findViewById(R.id.anonymousCheck);

        loginBtn.setOnClickListener(v -> {

            // Anonymous mode
            if (anonymousCheck.isChecked()) {
                goNext();
                return;
            }

            String e = email.getText().toString();
            String p = password.getText().toString();

            if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                email.setError("Enter valid email");
                return;
            }

            if (p.length() < 6) {
                password.setError("Minimum 6 characters");
                return;
            }

            goNext();
        });
    }

    void goNext() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class InputActivity extends AppCompatActivity {

    EditText decisionInput;
    Spinner urgencySpinner, categorySpinner;
    Button nextBtn;

    String[] urgency = {"Low", "Medium", "High"};
    String[] category = {"Career", "Life", "Relationship", "Finance"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        decisionInput = findViewById(R.id.decisionInput);
        urgencySpinner = findViewById(R.id.urgencySpinner);
        categorySpinner = findViewById(R.id.categorySpinner);
        nextBtn = findViewById(R.id.nextBtn);

        // Setup urgency spinner
        ArrayAdapter<String> urgencyAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                urgency
        );
        urgencySpinner.setAdapter(urgencyAdapter);

        // Setup category spinner
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                category
        );
        categorySpinner.setAdapter(categoryAdapter);

        nextBtn.setOnClickListener(v -> {

            String input = decisionInput.getText().toString().trim();

            if (input.isEmpty()) {
                decisionInput.setError("Please describe your situation");
                return;
            }

            // Store data
            DecisionData.decision = input;

            // Move to next screen
            startActivity(new Intent(InputActivity.this, QuestionsActivity.class));
        });
    }
}
package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ConfidenceActivity extends AppCompatActivity {

    TextView msgDynamic, msgFinal;
    Button finishBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confidence);

        msgDynamic = findViewById(R.id.msgDynamic);
        msgFinal = findViewById(R.id.msgFinal);
        finishBtn = findViewById(R.id.finishBtn);

        // 🔥 GET DATA FROM PREVIOUS PAGE
        String result = getIntent().getStringExtra("RESULT");

        if (result != null) {

            msgDynamic.setText("Based on your inputs: " + result);

            if (result.contains("growth")) {
                msgFinal.setText("This option supports learning, risk-taking, and future opportunities 🚀");
            } else {
                msgFinal.setText("This option provides security, consistency, and peace of mind 🛡️");
            }

        } else {
            msgDynamic.setText("No decision data received.");
            msgFinal.setText("Please go back and try again.");
        }

        // Move to final page
        finishBtn.setOnClickListener(v -> {
            startActivity(new Intent(ConfidenceActivity.this, FinalActivity.class));
        });
    }
}
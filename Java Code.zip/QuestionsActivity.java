package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class QuestionsActivity extends AppCompatActivity {

    Button growthBtn, stabilityBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        growthBtn = findViewById(R.id.growthBtn);
        stabilityBtn = findViewById(R.id.stabilityBtn);

        growthBtn.setOnClickListener(v -> {
            DecisionData.preference = "growth";
            goNext();
        });

        stabilityBtn.setOnClickListener(v -> {
            DecisionData.preference = "stability";
            goNext();
        });
    }

    void goNext() {
        startActivity(new Intent(this, ComparisonActivity.class));
    }
}
package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class ComparisonActivity extends AppCompatActivity {

    EditText option1, option2;
    Button analyzeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparison);

        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        analyzeBtn = findViewById(R.id.analyzeBtn);

        analyzeBtn.setOnClickListener(v -> {

            String op1 = option1.getText().toString().trim();
            String op2 = option2.getText().toString().trim();

            if (op1.isEmpty() || op2.isEmpty()) {
                Toast.makeText(this, "Enter both options", Toast.LENGTH_SHORT).show();
                return;
            }

            String pref = DecisionData.preference;
            String result;

            // Dynamic logic
            if ("growth".equals(pref)) {
                if (op1.length() > op2.length()) {
                    result = op1 + " is better for growth 🚀";
                } else {
                    result = op2 + " is better for growth 🚀";
                }
            } else {
                if (op1.length() > op2.length()) {
                    result = op1 + " is more stable 🛡️";
                } else {
                    result = op2 + " is more stable 🛡️";
                }
            }

            // 🔥 PASS DATA TO NEXT PAGE
            Intent intent = new Intent(ComparisonActivity.this, ConfidenceActivity.class);
            intent.putExtra("RESULT", result);
            startActivity(intent);
        });
    }
}
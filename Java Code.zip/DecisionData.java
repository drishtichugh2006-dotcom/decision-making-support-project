package com.example.herchoiceapp;

public class DecisionData {

    public static String decision = "";
    public static String preference = "";

}
package com.example.herchoiceapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FinalActivity extends AppCompatActivity {

    Button restartBtn, logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        restartBtn = findViewById(R.id.restartBtn);
        logoutBtn = findViewById(R.id.logoutBtn);

        // Start Again → goes to main screen
        restartBtn.setOnClickListener(v -> {
            Intent intent = new Intent(FinalActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });

        // Finish / Logout → closes app
        logoutBtn.setOnClickListener(v -> {
            finishAffinity(); // closes all activities
        });
    }
}